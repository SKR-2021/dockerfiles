#!/usr/bin/env python3
print('Hello from files-sample.com')
