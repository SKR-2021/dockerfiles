Sample TAR.GZ from files-sample.com
Contains 100 files.
